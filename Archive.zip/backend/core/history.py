from abc import ABC, abstractmethod

class Action(ABC):

    @property
    @abstractmethod
    def label(self) -> str: 
        pass

    @abstractmethod
    def execute(self) -> None:
        pass

    @abstractmethod
    def undo(self) -> None: 
        pass 

class History:
    def __init__(self):
        self._stack: list[Action] = []

    def run(self, action: Action) -> None:
        action.execute()
        self._stack.append(action)

    def label(self) -> str | None:
        if self._stack:
            return self._stack[-1].label
        return None

    def undo(self) -> None:
        if not self._stack:
            return
        self._stack[-1].undo()
        self._stack.pop()


history = History()