from core.history import history

class HistoryApi:
    def undo(self) -> None:
        history.undo()

    def undo_label(self) -> str | None:
        return history.label()