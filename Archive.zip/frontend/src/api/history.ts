import { call } from "./bridge";

export const undo = () => call<void>({ name: "undo" });

export const undoLabel = () => call<string | null>({ name: "undo_label" });
